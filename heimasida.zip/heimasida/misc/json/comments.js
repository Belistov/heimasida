// Placeholder for simulated persistent storage (can be extended or replaced with backend later)

// Sample user database (in-memory)
const users = {
    "demoUser": "password123"
  };
  
  // Sample comments for demo
  const comments = {
    tf2: [
      { user: "demoUser", text: "Looking to trade an Unusual!" }
    ],
    va: [
      { user: "demoUser", text: "Loved your last demo reel!" }
    ]
  };
  