let users = JSON.parse(localStorage.getItem("users")) || {};
let comments = JSON.parse(localStorage.getItem("comments")) || {
  tf2: [],
  va: []
};
let currentUser = null;
let currentMode = null;

function saveData() {
  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("comments", JSON.stringify(comments));
}

function registerUser() {
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    const steam = document.getElementById('steamUrl').value;
  
    if (users[user]) {
      updateStatus("User already exists.");
    } else {
      users[user] = { password: pass, steam };
      saveData();
      updateStatus("Registered successfully. You can now log in.");
    }
  }
  
  function loginUser() {
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    const steam = document.getElementById('steamUrl').value;
  
    if (users[user] && users[user].password === pass) {
      currentUser = user;
  
      // Update Steam URL if blank and newly entered
      if (steam && !users[user].steam) {
        users[user].steam = steam;
        saveData();
      }
  
      updateStatus("Logged in as " + user);
      renderComments();
    } else {
      updateStatus("Login failed.");
    }
  }


function selectMode(mode) {
  currentMode = mode;

  document.getElementById('modeSelect').classList.add("hidden");
  document.getElementById('auth').classList.remove("hidden");
  document.getElementById('tf2').classList.toggle("hidden", mode !== "tf2");
  document.getElementById('va').classList.toggle("hidden", mode !== "va");

  renderComments();
}

function postComment(section) {
  if (!currentUser) {
    alert("Please login first.");
    return;
  }

  const inputId = section === 'tf2' ? 'tf2Comment' : 'vaComment';
  const content = document.getElementById(inputId).value;
  if (content.trim() === "") return;

  comments[section].push({
    user: currentUser,
    text: content
  });

  saveData();
  document.getElementById(inputId).value = "";
  renderComments();
}

function renderComments() {
    ['tf2', 'va'].forEach(section => {
      const list = document.getElementById(section + 'CommentList');
      list.innerHTML = "";
  
      comments[section].forEach((c, i) => {
        const li = document.createElement("li");
  
        let userHtml = "";
  
        if (users[c.user]?.steam) {
          userHtml += `<a href="${users[c.user].steam}" target="_blank" title="View Steam Trade" style="margin-right:8px;">
            <img src="../misc/img/steam.png" alt="Steam" width="16" height="16" style="vertical-align:middle;">
          </a>`;
        }
  
        userHtml += `<strong>${c.user}:</strong> ${c.text}`;
        li.innerHTML = userHtml;
  
        if (currentUser && c.user === currentUser) {
          const btn = document.createElement("button");
          btn.textContent = "Delete";
          btn.style.marginLeft = "10px";
          btn.onclick = () => {
            comments[section].splice(i, 1);
            saveData();
            renderComments();
          };
          li.appendChild(btn);
        }
  
        list.appendChild(li);
      });
  
      // Disable comment input if not logged in
      const textarea = document.getElementById(section + "Comment");
      const postBtn = textarea.nextElementSibling;
      if (!currentUser) {
        textarea.disabled = true;
        postBtn.disabled = true;
        postBtn.textContent = "Login to Comment";
      } else {
        textarea.disabled = false;
        postBtn.disabled = false;
        postBtn.textContent = `Post ${section.toUpperCase()} Comment`;
      }
    });
  }
  
  
function updateStatus(msg) {
  document.getElementById("authStatus").innerText = msg;
}

window.onload = () => {
    renderComments();
  };
  